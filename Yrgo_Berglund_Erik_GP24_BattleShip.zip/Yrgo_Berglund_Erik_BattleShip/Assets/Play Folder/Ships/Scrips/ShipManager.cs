using System;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class ShipManager : MonoBehaviour
{
    [SerializeField] int mapSelected;
    
    int[,] gridMap = { //10x10

        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    int[,] gridMap1 = { //10x10

        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 1, 1, 1, 1, 0, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 2, 0, 3, 3, 3, 0, 0, 0, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    int[,] gridMap2 = { //10x10

        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 4, 4, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 2, 2, 2, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 3, 3, 3 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    int[,] gridMap3 = { //10x10

        { 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
        { 0, 4, 0, 0, 1, 0, 0, 0, 0, 0 },
        { 0, 4, 0, 0, 1, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 2, 2, 2, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    int[,] gridMap4 = { //10x10

        { 0, 2, 0, 0, 0, 0, 0, 0, 4, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 4, 0 },
        { 0, 2, 0, 0, 3, 3, 3, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 },
    };
    int[,] gridMap5 = { //10x10

        { 0, 0, 0, 0, 0, 5, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 5, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 3, 3, 3, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 2, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 2, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 2, 0, 0, 0, 0, 0, 0 },
    };
    int[,] gridMap6 = { //10x10

        { 0, 0, 0, 1, 0, 0, 0, 0, 0, 5 },
        { 0, 0, 0, 1, 0, 0, 0, 0, 0, 5 },
        { 0, 0, 0, 1, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 1, 0, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 4, 0, 0, 3, 0, 0 },
        { 0, 2, 0, 0, 4, 0, 0, 0, 0, 0 },
        { 0, 2, 0, 0, 4, 0, 0, 0, 0, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    
    private string attackType;
    private float cellSize = 0.8f;
    public List<bool> shipsAlive = new List<bool>();
    public List<string> objectIDs = new List<string>();
    private List<ShipID> shipBlockInGame = new List<ShipID>();
    public List<GameObject> BlocksToUpdate = new List<GameObject>();
    public ShipID shipBlock;
    
    [Header("Canvas")]
    public GameObject victory;
    public GameObject defeat;
    public Button menuButton;
    public TextMeshProUGUI displayText;
    
    [Header("Buttons")]
    public Button fireButton;
    public Button sonarButton;

    [Header("Missile")]
    public Missile missile;
    int missileAmmo = 30;
    public TextMeshProUGUI missileText;

    [Header("Torpedo")]
    public Torpedo torpedo;
    public bool disableCells;
    int torpedoAmmo = 5;
    public TextMeshProUGUI torpedoText;

    [Header("Sonar")]
    public Sonar sonar;
    public int sonarAmmo = 3;
    public TextMeshProUGUI sonarText;

    [Header("Selected Block")]
    public Vector3 selectedBlockLocation;
    public static ShipManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null)
            Destroy(gameObject);
        
        Instance = this;
    }

    private void Start()
    {
        CheckSavedData();
        // ClearSavedData();

        // PlayerPrefs.SetString("LoadLastGame", "false");
        // PlayerPrefs.SetInt("MapSelected", 0);
        // PlayerPrefs.SetInt("MapsCleared", 0);
        //Debug.Log(PlayerPrefs.GetString("ShipIDData"));

        SelectMap(PlayerPrefs.GetInt("MapSelected"));

        SpawnShips(PlayerPrefs.GetString("LoadLastGame"));

        UpdateDisplayText($"We Have detected {shipsAlive.Count} Ships, Captain.");
    }

    void CheckSavedData()
    {
        if (PlayerPrefs.GetString("ShipIDData") == "")
        {
            PlayerPrefs.SetString("ShipIDData", JsonUtility.ToJson(new ShipIDData()));
        }
        
        if (PlayerPrefs.GetString("AmmoData") == "")
        {
            PlayerPrefs.SetString("AmmoData", JsonUtility.ToJson(new AmmoData()));
        }
    }

    void SelectMap(int _mapSelected)
    {
        
        switch (_mapSelected)
        {
            case 0:
                Debug.Log("switch Case 0. No Map selected");
                return;

            case 1:
                gridMap = gridMap1;
                mapSelected = _mapSelected;
                return;
            
            case 2:
                gridMap = gridMap2;
                mapSelected = _mapSelected;
                return;
            
            case 3:
                gridMap = gridMap3;
                mapSelected = _mapSelected;
                return;
            
            case 4:
                gridMap = gridMap4;
                mapSelected = _mapSelected;
                return;
            
            case 5:
                gridMap = gridMap5;
                mapSelected = _mapSelected;
                return;
            
            case 6:
                gridMap = gridMap6;
                mapSelected = _mapSelected;
                return;
        }
    }

    public void SpawnShips(string _loadCheck)
    {
        int index = 0;
        ShipIDData shipIDData;

        Debug.Log(PlayerPrefs.GetString("ShipIDData"));
        Debug.Log(JsonUtility.FromJson<ShipIDData>(PlayerPrefs.GetString("ShipIDData")));
        
        if (_loadCheck == "false")
        {
            SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);
            shipIDData = new ShipIDData();
        }
        else
        {
            missileAmmo = LoadAmmo().missileAmmoValue;
            torpedoAmmo = LoadAmmo().torpedoAmmoValue;
            sonarAmmo = LoadAmmo().sonarAmmoValue;
            
            shipIDData = JsonUtility.FromJson<ShipIDData>(PlayerPrefs.GetString("ShipIDData"));
        }

        missileText.text = $"Missile: {missileAmmo}";
        torpedoText.text = $"Torpedo: {torpedoAmmo}";
        sonarText.text = $"Sonar: {sonarAmmo}";

        for (int x = 0; x < gridMap.GetLength(0); x++)
        {
            for (int y = 0; y < gridMap.GetLength(1); y++)
            {
                var shipInstance = Instantiate(shipBlock, GetWorldPosition(y, -x), default);
                
                if (_loadCheck == "true")
                {
                    //Debug.Log("Load");
                    shipInstance.Init(this, shipIDData.idValue[index], index, shipIDData.shipStateValue[index]);
                    BlockAdded(shipInstance);
                    SaveShipData(shipInstance);

                }
                else
                {
                    //Debug.Log("New Game");
                    shipInstance.Init(this, gridMap[x, y].ToString(), index, "Hidden");
                    BlockAdded(shipInstance);
                    SaveShipData(shipInstance);
                    PlayerPrefs.SetString("loadButtonDisabled", "false");
                }

                index++;
            }
        }
    }

    private Vector3 GetWorldPosition(int x, int y)
    {
        return new Vector3(x, y) * cellSize + new Vector3(cellSize, cellSize)*0.5f;
    }

    public void BlockAdded(ShipID _ship)
    {
        if (_ship.id != "0" && _ship.shipState != "HitShip")
        {
            Debug.Log(_ship.id);
            Debug.Log(_ship.shipState);

            if (objectIDs.Contains(_ship.id) == false)
            {
                Debug.Log("shipsAlive added");
                shipsAlive.Add(true);
            }

            objectIDs.Add(_ship.id);
        }
    }

    public void BlockRemoved(ShipID _ship)
    {
        if (_ship.id == "0")
        {
            UpdateShipID(_ship);
            return;
        }

        if (objectIDs.Contains(_ship.id))
        {
            objectIDs.Remove(_ship.id);
        }
        else
        {
            shipsAlive.RemoveAt(0);
        }

        UpdateShipID(_ship);
    }

    public void UpdateAndClear()
    {
        if (BlocksToUpdate.Count != 0)
        {
            foreach (GameObject items in BlocksToUpdate)
            {
                if (items.GetComponent<ShipID>() != null)
                {
                    items.GetComponent<ShipID>().UpdateStatusSprite();
                }
                else if (items.GetComponent<Launcher>() != null)
                {
                    items.GetComponent<Launcher>().UpdateStatusSprite();
                }
            }
            BlocksToUpdate.Clear();
        }
    }

    public void UpdateShipID(ShipID _shipID)
    {
        if (_shipID.id == "0")
        {
            UpdateDisplayText("No explosions detected.<br>We didn't hit anything.");
            return;
        }

        UpdateDisplayText("We hit a ship!");
        
        if (objectIDs.Contains(_shipID.id) == false)
        {
            shipsAlive.Remove(true);
            if (shipsAlive.Count > 0)
            {
                UpdateDisplayText($"Captain!<br>Enemy ship destroyed! There are {shipsAlive.Count} left");
            }
            else
            {    
                UpdateDisplayText($"Captain!All Enemy ship are destroyed!");
            }
        }

        EndGameCheck();
    }

    void EndGameCheck()
    {
        if (objectIDs.Count < 1)
        {
            ButtonsToDisable(true, fireButton, sonarButton);
            disableCells = true;
            victory.SetActive(true);
            ClearSavedData();

            if (PlayerPrefs.GetInt("MapsCleared")+1 == mapSelected)
            {
                PlayerPrefs.SetInt("MapsCleared", mapSelected);
            }

            return;
        }

        if (missileAmmo == 0 && torpedoAmmo == 0 && sonarAmmo == 0)
        {
            ButtonsToDisable(true, fireButton, sonarButton);
            disableCells = true;
            defeat.SetActive(true);
            ClearSavedData();
        }
    }

    public void UpdateAttack(string _attackName, Vector3 _location, string _updateText)
    {
        if (missileAmmo <= 0)
        {
            UpdateDisplayText("Captain!<br>We Don't have any Missile left!");
            return;
        }
        
        if (torpedoAmmo <= 0)
        {
            UpdateDisplayText("Captain!<br>We Don't have any Torpedoes left!");
            return;
        }

        attackType = _attackName;
        selectedBlockLocation = _location;
        

        UpdateDisplayText(_updateText);
    }

    public void UpdateDisplayText(string valueText)
    {
        displayText.text = valueText;
    }

    public void FireAttackButton()
    {
        if(attackType == "")
        {
            UpdateDisplayText("Captain, we don't have a target.");
        }
        else if (attackType == "Missile")
        {
            if (missileAmmo <= 0)
            {
                UpdateDisplayText("Captain!<br>We Don't have any Missile left!");
                return;
            }

            Instantiate(missile, selectedBlockLocation, default);
            missileAmmo--;
            missileText.text = $"Missile: {missileAmmo}";
            SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);
            attackType = "";
            
            if (missileAmmo == 0)
            {
                missileText.text = $"<s>Missile: {missileAmmo}<s>";
            }
        }
        else if (attackType == "Torpedo")
        {
            if (torpedoAmmo <= 0)
            {
                UpdateDisplayText("Captain!<br>We Don't have any Torpedoes left!");
                return;
            }

            disableCells = true;
            UpdateDisplayText($"Launching {attackType}.");
            Instantiate(torpedo, selectedBlockLocation, default);
            torpedoAmmo--;
            torpedoText.text = $"Torpedo: {torpedoAmmo}";
            SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);
            attackType = "";

            if (torpedoAmmo == 0)
            {
                torpedoText.text = $"<s>Torpedo: {torpedoAmmo}<s>";
            }
        }
    }

    public void FireSonarButton()
    {
        attackType = "Sonar";

        if (sonarAmmo <= 0)
        {
            UpdateDisplayText("Captain!<br>We Don't have any Sonar left!");
            return;
        }

        Instantiate(sonar, selectedBlockLocation, default);
        sonarAmmo--;
        sonarText.text = $"Sonar: {sonarAmmo}";
        SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);
        attackType = "";

        if (sonarAmmo == 0)
        {
            sonarText.text = $"<s>Sonar: {sonarAmmo}<s>";
        }
    }

    public void DisableButtons(bool _value = true)
    {
        ButtonsToDisable(_value, fireButton, sonarButton, menuButton);
    }

    void ButtonsToDisable(bool _disable = true, params Button[] buttons)
    {
        if (buttons == null)
        {
            return;
        }

        for (int i = 0; i < buttons.Length; i++)
        {
            buttons[i].interactable = !_disable;
        }
    }    
    
    void ClearSavedData()
    {
        PlayerPrefs.SetString("ShipIDData", JsonUtility.ToJson(new ShipIDData()));
        PlayerPrefs.SetString("AmmoData", JsonUtility.ToJson(new AmmoData()));

        PlayerPrefs.SetString("loadButtonDisabled", "true");
    }

    public void SaveShipData(ShipID _shipID)
    {
        string dataString = PlayerPrefs.GetString("ShipIDData");
        ShipIDData shipData = JsonUtility.FromJson<ShipIDData>(dataString);

        shipData.idValue[_shipID.objectIndex] = _shipID.id;
        shipData.shipStateValue[_shipID.objectIndex] = _shipID.shipState;
        
        PlayerPrefs.SetString("ShipIDData", JsonUtility.ToJson(shipData));
    }

    private void SaveAmmoData(int _missileAmmo, int _torpedoAmmo, int _sonarAmmo)
    {
        AmmoData totalAmmoData = JsonUtility.FromJson<AmmoData>(PlayerPrefs.GetString("AmmoData"));

        totalAmmoData.missileAmmoValue = _missileAmmo;
        totalAmmoData.torpedoAmmoValue = _torpedoAmmo;
        totalAmmoData.sonarAmmoValue = _sonarAmmo;

        PlayerPrefs.SetString("AmmoData", JsonUtility.ToJson(totalAmmoData));
    }

    public ShipIDData LoadShipID()
    {
        string dataString = PlayerPrefs.GetString("ShipIDData");
        ShipIDData loadData = JsonUtility.FromJson<ShipIDData>(dataString);

        return loadData;
    }

    private AmmoData LoadAmmo()
    {
        if(PlayerPrefs.GetString("AmmoData") == "")
        {
            PlayerPrefs.SetString("AmmoData", JsonUtility.ToJson(new AmmoData()));
            Debug.Log(PlayerPrefs.GetString("AmmoData"));
        }
        
        AmmoData loadData = JsonUtility.FromJson<AmmoData>(PlayerPrefs.GetString("AmmoData"));

        return loadData;
    }
}

[Serializable]
public class ShipIDData
{
    public string[] idValue = new string[100] { //10x10

        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
    };
    public string[] shipStateValue = new string[100] {

        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
        "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
    };
}

[Serializable]
public class AmmoData
{
    public int missileAmmoValue = 30;
    public int torpedoAmmoValue = 5;
    public int sonarAmmoValue = 3;
}