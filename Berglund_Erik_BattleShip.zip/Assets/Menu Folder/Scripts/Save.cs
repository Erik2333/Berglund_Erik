using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Save : MonoBehaviour
{
    //string myString = "Unsaved Sting";
    
    void Start()
    {
        string loadString = PlayerPrefs.GetString("saveValue", "No String Found");

        Debug.Log(loadString);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            PlayerPrefs.SetString("saveValue", "modified String");
            
            Debug.Log("String Saved");
        }

        if (Input.GetKeyDown(KeyCode.Delete))
        {
            PlayerPrefs.DeleteAll();
            
            Debug.Log("Saves Deleted");
        }
    }
}
