using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Launcher : MonoBehaviour
{
    public string launcherStatus;
    SpriteRenderer spriteRenderer;
    [SerializeField] Sprite crosshair;
    [SerializeField] SpriteRenderer spriteUnder;
    Sprite defaultSprite;

    private void Start() {
        spriteRenderer = GetComponent<SpriteRenderer>();
        defaultSprite = GetComponent<SpriteRenderer>().sprite;
    }

    private void OnMouseDown()
    {
        if (ShipManager.Instance.disableCells == true)
        {
            return;
        }

        ShipManager.Instance.UpdateAndClear();
        
        if (launcherStatus == "Selected")
        {
            UpdateStatusSprite();
            return;
        }

        
        UpdateStatusSprite("Selected");
        
        ShipManager.Instance.BlocksToUpdate.Add(gameObject);
    }

    internal void UpdateStatusSprite(string _state = default)
    {
        if (_state == default)
        {
            _state = "Deselected";
        }

        switch (_state)
        {
            case "Deselected":
                launcherStatus = "Deselected";
                spriteRenderer.sprite = defaultSprite;
                ShipManager.Instance.UpdateAttack("", Vector3.zero, " ");
                return;

            case "Selected":
                launcherStatus = "Selected";
                spriteRenderer.sprite = crosshair;
                ShipManager.Instance.UpdateAttack("Torpedo", transform.position, "Torpedo Ready Captain.");
                return;
        }
    }
}
