using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class NewShipManager : MonoBehaviour

{
    public int mapSelected;
    bool loadSavedGame;
    
    int[,] gridMap = { //10x10

        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };

    int[,] gridMap1 = { //10x10

        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 1, 1, 1, 1, 0, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 2, 0, 3, 3, 3, 0, 0, 0, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };

    int[,] gridMap2 = { //10x10

        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 4, 4, 0, 0 },
        { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 2, 2, 2, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 3, 3, 3 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    
    int[,] gridMap3 = { //10x10

        { 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
        { 0, 4, 0, 0, 1, 0, 0, 0, 0, 0 },
        { 0, 4, 0, 0, 1, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 2, 2, 2, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    
    int[,] gridMap4 = { //10x10

        { 0, 2, 0, 0, 0, 0, 0, 0, 4, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 4, 0 },
        { 0, 2, 0, 0, 3, 3, 3, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 },
    };

    int[,] gridMap5 = { //10x10

        { 0, 0, 0, 0, 0, 5, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 5, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 3, 3, 3, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 2, 0, 0, 0, 0, 0, 4 },
        { 0, 0, 0, 2, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 2, 0, 0, 0, 0, 0, 0 },
    };
    
    int[,] gridMap6 = { //10x10

        { 0, 0, 0, 1, 0, 0, 0, 0, 0, 5 },
        { 0, 0, 0, 1, 0, 0, 0, 0, 0, 5 },
        { 0, 0, 0, 1, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 1, 0, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 3, 0, 0 },
        { 0, 0, 0, 0, 4, 0, 0, 3, 0, 0 },
        { 0, 2, 0, 0, 4, 0, 0, 0, 0, 0 },
        { 0, 2, 0, 0, 4, 0, 0, 0, 0, 0 },
        { 0, 2, 0, 0, 0, 0, 0, 0, 0, 0 },
        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };
    
    private string attackType;
    private float cellSize = 0.8f;
    private List<bool> shipsAlive = new List<bool>();
    private List<string> objectIDs = new List<string>();
    private List<ShipID> shipBlockInGame = new List<ShipID>();
    public List<GameObject> BlocksToUpdate = new List<GameObject>();
    public ShipID shipBlock;
    
    [Header("Canvas")]
    public GameObject victory;
    public GameObject defeat;
    public TextMeshProUGUI displayText;
    

    [Header("Buttons")]
    public Button fireButton;
    public Button sonarButton;

    [Header("Missile")]
    public Missile missile;
    int missileAmmo = 30;
    public TextMeshProUGUI missileText;

    [Header("Torpedo")]
    public Torpedo torpedo;
    public bool disableCells;
    int torpedoAmmo = 5;
    public TextMeshProUGUI torpedoText;

    [Header("Sonar")]
    public Sonar sonar;
    public int sonarAmmo = 3;
    public TextMeshProUGUI sonarText;

    [Header("Selected Block")]
    public Vector3 selectedBlockLocation;

    public static NewShipManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null)
            Destroy(gameObject);
        
        Instance = this;
    }

    private void Start()
    {
        // ClearSavedData();

        // PlayerPrefs.SetString("LoadLastGame", "false");
        // PlayerPrefs.SetInt("MapSelected", 0);
        // PlayerPrefs.SetInt("MapsCleared", 0);

        //LoadCheck(PlayerPrefs.GetString("LoadLastGame"));

        SelectMap(mapSelected);//PlayerPrefs.GetInt("MapSelected")

        SpawnShips();

        //UpdateDisplayText($"We Have detected {shipsAlive.Count} Ships, Captain.");
    }

    void LoadCheck(string _loadCheck)
    {
        if (_loadCheck == "true")
        {
            loadSavedGame = true;
        }
        else
        {
            loadSavedGame = false;
        }
    }

    void SelectMap(int _mapSelected)
    {
        
        switch (_mapSelected)
        {
            case 0:
                return;

            case 1:
                gridMap = gridMap1;
                mapSelected = _mapSelected;
                return;
            
            case 2:
                gridMap = gridMap2;
                mapSelected = _mapSelected;
                return;
            
            case 3:
                gridMap = gridMap3;
                mapSelected = _mapSelected;
                return;
            
            case 4:
                gridMap = gridMap4;
                mapSelected = _mapSelected;
                return;
            
            case 5:
                gridMap = gridMap5;
                mapSelected = _mapSelected;
                return;
            
            case 6:
                gridMap = gridMap6;
                mapSelected = _mapSelected;
                return;

        }
    }

    public void SpawnShips()
    {
        int index = 0;
        ShipIDData shipIDData = null;
        
        // if (PlayerPrefs.GetString("LoadLastGame") == true)
        // {
        //     TotalAmmoData loadedAmmo = LoadAmmoFromJsonFile();
        //     missileAmmo = loadedAmmo.missileAmmoValue;
        //     torpedoAmmo = loadedAmmo.torpedoAmmoValue;
        //     sonarAmmo = loadedAmmo.sonarAmmoValue;
        
        //     // Generate last save map.
        //     shipIDData = LoadShipIDFromJsonFile();
        // }
        // else
        // {
        //     SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);
        // }

        //missileText.text = $"Missile: {missileAmmo}";
        //torpedoText.text = $"Torpedo: {torpedoAmmo}";
        //sonarText.text = $"Sonar: {sonarAmmo}";

        for (int x = 0; x < gridMap.GetLength(0); x++)
        {
            for (int y = 0; y < gridMap.GetLength(1); y++)
            {
                var shipInstance = Instantiate(shipBlock, GetWorldPosition(y, -x), default);
                
                if (loadSavedGame == true)
                {
                    //shipInstance.Init(this, shipIDData.idValue[index], index, shipIDData.shipStateValue[index]);
                    shipBlockInGame.Add(shipInstance);
                    BlockAdded(shipIDData.idValue[index], shipIDData.shipStateValue[index]);
                    SaveData(shipInstance, index);
                }
                else
                {
                    
                }

                //shipInstance.Init(this, gridMap[x, y].ToString(), index, "Hidden");
                shipBlockInGame.Add(shipInstance);
                BlockAdded(gridMap[x, y].ToString());
                SaveData(shipInstance, index);

                index++;
            }
        }
    }

    private Vector3 GetWorldPosition(int x, int y)
    {
        return new Vector3(x, y) * cellSize + new Vector3(cellSize, cellSize)*0.5f;
    }

    public void BlockAdded(string _objectIDs, string _shipStatus = null)
    {
        if (_objectIDs == "0" || _shipStatus == "HitShip")
        {
            return;
        }

        if (objectIDs.Contains(_objectIDs) == false)
        {
            shipsAlive.Add(true);
        }
        
        objectIDs.Add(_objectIDs);
    }

    public void UpdateAndClear()
    {
        if (BlocksToUpdate.Count != 0)
        {
            foreach (GameObject items in BlocksToUpdate)
            {
                if (items.GetComponent<ShipID>() != null)
                {
                    items.GetComponent<ShipID>().UpdateStatusSprite();
                    continue;
                }
                else if (items.GetComponent<Launcher>() != null)
                {
                    items.GetComponent<Launcher>().UpdateStatusSprite();
                }
            }
            
            BlocksToUpdate.Clear();
        }
    }

    public void UpdateShipID(ShipID _shipID, int _index)
    {
        SaveData(_shipID, _index);

        if (_shipID.id == "0")
        {
            UpdateDisplayText("No explosions detected.<br>We didn't hit anything.");
            return;
        }

        objectIDs.Remove(_shipID.id);
        UpdateDisplayText("We hit a ship!");
        
        if (!objectIDs.Contains(_shipID.id))
        {
            UpdateDisplayText($"Captain!<br>Enemy ship destroyed! There are {shipsAlive.Count-1} left");
            Debug.Log("Remove");
            shipsAlive.Remove(true);
        }

        if (shipsAlive.Count < 1)
        {
            ButtonsToDisable(true, fireButton, sonarButton);
            disableCells = true;
            victory.SetActive(true);
            ClearSavedData();

            if (PlayerPrefs.GetInt("MapsCleared")+1 == mapSelected)
            {
                PlayerPrefs.SetInt("MapsCleared", mapSelected);
            }

            return;
        }

        if (missileAmmo == 0 && torpedoAmmo == 0 && sonarAmmo == 0)
        {
            ButtonsToDisable(true, fireButton, sonarButton);
            disableCells = true;
            defeat.SetActive(true);
            ClearSavedData();
        }
    }

    public void SaveData(ShipID _shipID, int _index)
    {
        PlayerPrefs.SetString("loadButtonDisabled", "false");
        
        string filePath = Application.persistentDataPath + "/ShipIDDataSave.json";

        if (!File.Exists(filePath))
        {
            //Creating File
            File.WriteAllText(filePath, JsonUtility.ToJson(new ShipIDData()));
        }
        
        string jsonString = File.ReadAllText(filePath);
        ShipIDData shipData = JsonUtility.FromJson<ShipIDData>(jsonString);

        shipData.idValue[_index] = _shipID.id;
        shipData.shipStateValue[_index] = _shipID.shipState;

        if (File.Exists(filePath))
        {
            if (File.ReadAllText(filePath) != JsonUtility.ToJson(shipData, true))
            {
                //Overwrite File
                File.WriteAllText(filePath, JsonUtility.ToJson(shipData, true));
            }
        }
    }

    void ClearSavedData()
    {
        string shipDataFilePath = Application.persistentDataPath + "/ShipIDDataSave.json";
        string ammoDataFilePath = Application.persistentDataPath + "/TotalAmmoDataSave.json";

        if (File.Exists(shipDataFilePath))
        {
            File.WriteAllText(shipDataFilePath, JsonUtility.ToJson(new ShipIDData()));
        }

        if (File.Exists(ammoDataFilePath))
        {
            File.WriteAllText(ammoDataFilePath, JsonUtility.ToJson(new TotalAmmoData()));
        }

        PlayerPrefs.SetString("loadButtonDisabled", "true");
    }

    private void SaveAmmoData(int _missileAmmo, int _torpedoAmmo, int _sonarAmmo)
    {
        string filePath = Application.persistentDataPath + "/TotalAmmoDataSave.json";

        if (!File.Exists(filePath))
        {
            File.WriteAllText(filePath, JsonUtility.ToJson(new TotalAmmoData(), true));
        }

        string jsonString = File.ReadAllText(filePath);
        TotalAmmoData totalAmmoData = JsonUtility.FromJson<TotalAmmoData>(jsonString);

        totalAmmoData.missileAmmoValue = _missileAmmo;
        totalAmmoData.torpedoAmmoValue = _torpedoAmmo;
        totalAmmoData.sonarAmmoValue = _sonarAmmo;

        if (File.Exists(filePath))
        {
            if (File.ReadAllText(filePath) != JsonUtility.ToJson(totalAmmoData, true))
            {
                File.WriteAllText(filePath, JsonUtility.ToJson(totalAmmoData, true));
            }
            
        }
    }

    public ShipIDData LoadShipIDFromJsonFile(){
        string jsonFileString = File.ReadAllText(Application.persistentDataPath + "/ShipIDDataSave.json");
        ShipIDData loadData = JsonUtility.FromJson<ShipIDData>(jsonFileString);

        return loadData;
    }

    private TotalAmmoData LoadAmmoFromJsonFile(){
        string jsonString = File.ReadAllText(Application.persistentDataPath + "/TotalAmmoDataSave.json");
        TotalAmmoData loadData = JsonUtility.FromJson<TotalAmmoData>(jsonString);

        return loadData;
    }

    public void UpdateAttack(string _attackName, Vector3 _location, string _updateText)
    {
        attackType = _attackName;
        selectedBlockLocation = _location;
        UpdateDisplayText(_updateText);
    }

    public void UpdateDisplayText(string valueText)
    {
        displayText.text = valueText;
    }

    public void FireAttackButton()
    {
        if (attackType == "Missile")
        {
            if (missileAmmo <= 0)
            {
                UpdateDisplayText("Captain!<br>We Don't have any Missile left!");
                return;
            }

            Instantiate(missile, selectedBlockLocation, default);
            missileAmmo--;
            missileText.text = $"Missile: {missileAmmo}";
            SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);
            
            if (missileAmmo == 0)
                missileText.text = $"<s>Missile: {missileAmmo}<s>";
        }
        else if (attackType == "Torpedo")
        {
            if (torpedoAmmo <= 0)
            {
                UpdateDisplayText("Captain!<br>We Don't have any Torpedoes left!");
                return;
            }

            disableCells = true;
            UpdateDisplayText($"Launching {attackType}.");
            Instantiate(torpedo, selectedBlockLocation, default);
            torpedoAmmo--;
            torpedoText.text = $"Torpedo: {torpedoAmmo}";
            SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);

            if (torpedoAmmo == 0)
                torpedoText.text = $"<s>Torpedo: {torpedoAmmo}<s>";
        }
    }

    public void FireSonarButton()
    {
        attackType = "Sonar";

        if (sonarAmmo <= 0)
        {
            UpdateDisplayText("Captain!<br>We Don't have any Sonar left!");
            return;
        }

        Instantiate(sonar, selectedBlockLocation, default);
        sonarAmmo--;
        sonarText.text = $"Sonar: {sonarAmmo}";
        SaveAmmoData(missileAmmo, torpedoAmmo, sonarAmmo);

        if (sonarAmmo == 0)
            sonarText.text = $"<s>Sonar: {sonarAmmo}<s>";
    }

    public void DisableButtons(bool _value = true)
    {
        ButtonsToDisable(_value, fireButton, sonarButton);
    }

    void ButtonsToDisable(bool _disable = true, params Button[] buttons)
    {
        if (buttons == null)
        {
            return;
        }

        for (int i = 0; i < buttons.Length; i++)
        {
            buttons[i].interactable = !_disable;
        }
    }
}

// [Serializable]
// public class ShipIDData
// {
//     public string[] idValue = new string[100] { //10x10

//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//         "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
//     };
//     public string[] shipStateValue = new string[100] {

//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//         "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden", "Hidden",
//     };
// }

// [Serializable]
// public class TotalAmmoData
// {
//     public int missileAmmoValue;
//     public int torpedoAmmoValue;
//     public int sonarAmmoValue;
// }