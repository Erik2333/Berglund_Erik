using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.InputSystem;




public class TestClass : MonoBehaviour
{
    private GameMap grid;
    public int width, height;
    public float cellSize;

    private void Start()
    {
        grid = new GameMap(width, height, cellSize);
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            grid.SetValue(GetMouseWorldPosition(), 10);
        }

        // // New input system
        // if (Mouse.current.leftButton.isPressed)
        // {
        //     grid.SetValue(GetMouseWorldPosition(), 42);
        // }
    }

    // New input system
    // public static Vector3 GetMouseWorldPosition()
    // {
    //     Vector3 vec = GetMouseWorldPositionWithZ(Mouse.current.position.ReadValue(), Camera.main);
    //     vec.z = 0f;
    //     return vec;
    // }

    Vector3 GetMouseWorldPosition()
    {
        Vector3 vec = GetMouseWorldPositionWithZ(Input.mousePosition, Camera.main);
        vec.z = 0f;
        Debug.Log((Vector2)vec);
        return vec;
    }

    Vector3 GetMouseWorldPositionWithZ()
    {
        return GetMouseWorldPositionWithZ(Input.mousePosition, Camera.main);
    }

    Vector3 GetMouseWorldPositionWithZ(Camera worldCamera)
    {
        return GetMouseWorldPositionWithZ(Input.mousePosition, worldCamera);
    }

    Vector3 GetMouseWorldPositionWithZ(Vector3 screenPosition, Camera worldCamera)
    {
        Vector3 worldPosition = worldCamera.ScreenToWorldPoint(screenPosition);
        return worldPosition;
    }
}
