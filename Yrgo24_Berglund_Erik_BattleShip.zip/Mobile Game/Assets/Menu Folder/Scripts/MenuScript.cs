using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{

    [SerializeField] GameObject buttonPanelObject;
    [SerializeField] Button[] playButtons;
    [SerializeField] GameObject MapSetupObject;
    [SerializeField] GameObject optionsObject;
    [SerializeField] GameObject creditsObject;

    private void Start() {

        //Debug.Log($"LoadLastGame = {PlayerPrefs.GetString("LoadLastGame")}");
        //Debug.Log($"MapSelected = {PlayerPrefs.GetInt("MapSelected")}");
        //Debug.Log($"MapsCleared = {PlayerPrefs.GetInt("MapsCleared")}");

        
        if (PlayerPrefs.HasKey("Builded") == false);
        {
            PlayerPrefs.SetString("Builded", "true");
            PlayerPrefs.SetString("loadButtonDisabled", "false");
            PlayerPrefs.SetString("LoadLastGame", "false");
            PlayerPrefs.SetInt("MapSelected", 0);
            PlayerPrefs.SetInt("MapsCleared", 0);
        }

        if (SceneManager.GetActiveScene().buildIndex == 0)
        {

            for (int i = 0; i < PlayerPrefs.GetInt("MapsCleared"); i++)
            {
                //Debug.Log(playButtons[i+1].name);
                playButtons[i+1].interactable = true;
            }

            if (PlayerPrefs.GetString("loadButtonDisabled") == "false")
            { 
                //Debug.Log(playButtons[6].name);
                playButtons[6].interactable = true;
            }
        }
    }

    public void ButtonMaps()
    {
        //Debug.Log("ButtonMaps");
        MapSetupObject.SetActive(!MapSetupObject.activeSelf);
        buttonPanelObject.SetActive(!buttonPanelObject.activeSelf);
        
        if (MapSetupObject.activeSelf || buttonPanelObject.activeSelf)
        {
            return;
        }
        else
        {
            buttonPanelObject.SetActive(true);
        }
        
    }

    public void ButtonOptions()
    {
        //Debug.Log("ButtonOptions");
        optionsObject.SetActive(!optionsObject.activeSelf);
        buttonPanelObject.SetActive(!buttonPanelObject.activeSelf);
        
        if (optionsObject.activeSelf || buttonPanelObject.activeSelf)
        {
            return;
        }
        else
        {
            buttonPanelObject.SetActive(true);
        }
    }

    

    public void ButtonCredits()
    {
        //Debug.Log("ButtonCredits");
        creditsObject.SetActive(!creditsObject.activeSelf);
        buttonPanelObject.SetActive(!buttonPanelObject.activeSelf);

        if (creditsObject.activeSelf || buttonPanelObject.activeSelf)
        {
            return;
        }
        else
        {
            buttonPanelObject.SetActive(true);
        }
    }

    public void ButtonQuit()
    {
        //Debug.Log("ButtonQuit");
        Application.Quit();
    }

    public void ButtonOptionsInPlay()
    {
        //Debug.Log("ButtonOptions");
        optionsObject.SetActive(!optionsObject.activeSelf);
    }

    public void ButtonReturnToMenu()
    {
        //Debug.Log("ButtonReturnToMenu");
        SceneManager.LoadScene(0);
    }

    public void ButtonStartLevel1()
    {
        //Debug.Log("ButtonStartLevel1");
        PlayerPrefs.SetInt("MapSelected", 1);
        PlayerPrefs.SetString("LoadLastGame", "false");
        SceneManager.LoadScene(1);
    }

    public void ButtonStartLevel2()
    {
        //Debug.Log("ButtonStartLevel2");
        PlayerPrefs.SetInt("MapSelected", 2);
        PlayerPrefs.SetString("LoadLastGame", "false");
        SceneManager.LoadScene(1);
    }

    public void ButtonStartLevel3()
    {
        //Debug.Log("ButtonStartLevel3");
        PlayerPrefs.SetInt("MapSelected", 3);
        PlayerPrefs.SetString("LoadLastGame", "false");
        SceneManager.LoadScene(1);
    }

    public void ButtonStartLevel4()
    {
        //Debug.Log("ButtonStartLevel4");
        PlayerPrefs.SetInt("MapSelected", 4);
        PlayerPrefs.SetString("LoadLastGame", "false");
        SceneManager.LoadScene(1);
    }

    public void ButtonStartLevel5()
    {
        //Debug.Log("ButtonStartLevel5");
        PlayerPrefs.SetInt("MapSelected", 5);
        PlayerPrefs.SetString("LoadLastGame", "false");
        SceneManager.LoadScene(1);
    }

    public void ButtonStartLevel6()
    {
        //Debug.Log("ButtonStartLevel6");
        PlayerPrefs.SetInt("MapSelected", 2);
        PlayerPrefs.SetString("LoadLastGame", "false");
        SceneManager.LoadScene(1);
    }

    public void ButtonLoadGame()
    {
        //Debug.Log("ButtonLoadGame");
        PlayerPrefs.SetInt("MapSelected", 0);
        PlayerPrefs.SetString("LoadLastGame", "true");
        SceneManager.LoadScene(1);
    }
}
