using System.Collections.Generic;
using UnityEngine;


public class ShipID : MonoBehaviour
{
    public string shipState;
    public string id;
    public int objectIndex;

    [Header("Sprites")]
    [SerializeField] Sprite crosshair;
    [SerializeField] Sprite defaultSprite;
    [SerializeField] Sprite HitEmptySprite;
    [SerializeField] SpriteRenderer spriteUnderneath;
    [SerializeField] Sprite HitBySonarSprite;
    [SerializeField] Sprite HitSprite;
    SpriteRenderer spriteRenderer;

    private void Start() 
    {
        spriteRenderer = GetComponent<SpriteRenderer>();

        UpdateStatusSprite();
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name.Contains("Sonar") == true)
        {
            UpdateStatusSprite("HitBySonar");
            Save();
            return;
        }

        if (id == "0")
        {
            UpdateStatusSprite("HitEmpty");
            ShipManager.Instance.BlockRemoved(this);
        }
        else
        {
            UpdateStatusSprite("HitShip");
            ShipManager.Instance.BlockRemoved(this);
        }
        Save();
    }

    private void OnMouseDown()
    {

        if (ShipManager.Instance.disableCells == true)
        {
            return;
        }

        if (spriteRenderer.sprite == crosshair)
        {
            UpdateStatusSprite();
            ShipManager.Instance.UpdateAttack("", Vector3.zero, " ");
            return;
        }
        else
        {
            UpdateStatusSprite("Selected");
            ShipManager.Instance.UpdateAttack("Missile", transform.position, "Locked on Target, Captain.");
        }
        
        
        ShipManager.Instance.UpdateAndClear();
        ShipManager.Instance.BlocksToUpdate.Add(gameObject);
        
    }

    internal void UpdateStatusSprite(string _state = default)
    {
        if (_state == default)
        {
            _state = shipState;
        }

        switch (_state)
        {
            case "Selected":
                spriteRenderer.sprite = crosshair;
            return;
                
            case "Hidden":
                shipState = _state;

                spriteRenderer.sprite = defaultSprite;
            return;

            case "HitEmpty":
                shipState = _state;

                spriteRenderer.sprite = HitEmptySprite;
            return;

            case "HitBySonar":
                if (shipState == "HitShip")
                {
                    return;
                }

                if (id == "0")
                {
                    shipState = "HitEmpty";
                    spriteRenderer.sprite = HitEmptySprite;
                    return;
                }

                shipState = _state;

                spriteUnderneath.enabled = true;
                spriteUnderneath.sprite = HitBySonarSprite;
                spriteRenderer.sprite = defaultSprite;
            return;

            case "HitShip":
                shipState = _state;

                spriteUnderneath.enabled = true;
                spriteUnderneath.sprite = HitSprite;
                spriteRenderer.sprite = defaultSprite;
            return;
        }
    }

    void Save()
    {
        ShipManager.Instance.SaveShipData(this);
    }

    internal void Init(ShipManager shipManager, string _id, int _objectIndex, string _status)
    {
        id = _id;
        
        objectIndex = _objectIndex;

        shipState = _status;
    }
}