using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OldGridSystem : MonoBehaviour
{
    int[,] myArray = new int[10,10]
    {
        { 9, 9, 9, 9, 9, 9, 9, 9, 9, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 1, 1, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 1, 9 },
        { 9, 0, 0, 0, 0, 1, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 1, 1, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 9, 9, 9, 9, 9, 9, 9, 9, 9 }
    };

    int[,] myArray2 = new int[12,12]
    {
        { 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9 },
        { 9, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 9 },
        { 9, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 9 },
        { 9, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 9 },
        { 9, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9 },
        { 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9 },
    };
    
    int[,] testGrid;
    int[,] spawnGrid;

    int horizontal, vertical, columns, rows;
    public int indexPositionValue;
    public int aliveNeighbors;
    public Sprite sprite;
    // Start is called before the first frame update
    void Start()
    {
        QualitySettings.vSyncCount = 0;
		// Application.targetFrameRate = 4;

        vertical = (int)Camera.main.orthographicSize + 1;
        horizontal = (int)Camera.main.orthographicSize * (Screen.width / Screen.height) + 1;
        columns = horizontal * 2;
        rows = vertical * 2;
        testGrid = new int[columns, rows];
        spawnGrid = new int[columns, rows];
        
        CellValueDesignator(testGrid);
        CellColorDesignator(testGrid);
    }

    // Update is called once per frame
    void Update()
    {
        CellAwake(testGrid);
        CellNeighborChecker(testGrid, spawnGrid); // Need to make it check only around Living cells.
        DeadAndSpawnerNewCells(testGrid);
        CellColorDesignator(testGrid);
    }

    public void CellValueDesignator(int[,] array)
    {
        for (int y = array.GetLength(1)-1; y > -1; y--) //start at seven and -1 until y == -1
        {
            for (int x = 0; x < array.GetLength(0); x++)
            {
                if (x == 0 || x == array.GetLength(1)-1 || y == 0 || y == array.GetLength(0)-1)
                {
                    array[y, x] = 9;
                    continue;
                }
                else
                {                
                    array[y, x] = Random.Range(0, 2);
                    Debug.Log(array[y, x]);
                }
            }
        }
    }

    public void CellAwake(int[,] array)
    {
        for (int y = 0; y < array.GetLength(0); y++)
        {
            for (int x = 0; x < array.GetLength(1); x++)
            {
                indexPositionValue = array[y,x];
                
                if (indexPositionValue != 1)
                {
                    continue;
                }
                
                if (indexPositionValue == 1)
                {
                    if (array[y-1, x-1] == -1 ) // up left
                    {
                        array[y-1, x-1] = 0;
                    }

                    if (array[y-1, x] == -1) // up
                    {
                        array[y-1, x] = 0;
                    }
                    
                    if (array[y-1, x+1] == -1) // up right
                    {
                        array[y-1, x+1] = 0;
                    }

                    if (array[y, x-1] == -1 ) // Check neighbors left.
                    {
                        array[y, x-1] = 0;
                    }

                    if (array[y, x+1] == -1) // Check neighbors right.
                    {
                        array[y, x+1] = 0;
                    }

                    if (array[y+1, x-1] == -1 ) // down left
                    {
                        array[y+1, x-1] = 0;
                    }

                    if (array[y+1, x] == -1) // down
                    {
                        array[y+1, x] = 0;
                    }
                    
                    if (array[y+1, x+1] == -1) // down right
                    {
                        array[y+1, x+1] = 0;
                    }
                }
            }
        }
    
        for (int y = 0; y < array.GetLength(0); y++)
        {
            for (int x = 0; x < array.GetLength(1); x++)
            {
                if (spawnGrid[y,x] == 2 || spawnGrid[y,x] == 3)
                {
                    array[y, x] = spawnGrid[y,x];
                    spawnGrid[y,x] = 0;
                }
            }
        }
    }

    public void CellNeighborChecker(int[,] array, int[,] array2)
    {
        for (int y = 0; y < array.GetLength(0); y++)
        {
            for (int x = 0; x < array.GetLength(1); x++)
            {
                indexPositionValue = array[y, x];
                aliveNeighbors = 0;


                if (indexPositionValue == 9 )//|| indexPositionValue == -1
                {
                    continue;
                }
                
                if (array[y-1, x-1] == 1 ) // up left
                {
                    aliveNeighbors++;
                }

                if (array[y-1, x] == 1) // up
                {
                    aliveNeighbors++;
                }
                
                if (array[y-1, x+1] == 1) // up right
                {
                    aliveNeighbors++;
                }

                if (array[y, x-1] == 1 ) // Check neighbors left.
                {
                    aliveNeighbors++;
                }

                if (array[y, x+1] == 1) // Check neighbors right.
                {
                    aliveNeighbors++;
                }

                if (array[y+1, x-1] == 1 ) // down left
                {
                    aliveNeighbors++;
                }

                if (array[y+1, x] == 1) // down
                {
                    aliveNeighbors++;
                }
                
                if (array[y+1, x+1] == 1) // down right
                {
                    aliveNeighbors++;
                }

                if (indexPositionValue == 0 && aliveNeighbors < 1)
                {
                    array[y,x] = -1;
                }


                if (indexPositionValue == 0 && aliveNeighbors == 3)
                {
                    spawnGrid[y,x] = 2;
                    // Debug.Log("Cell X: " + x + " Y: " + y + " Value of spawnGrid: " + spawnGrid[y,x]);
                }

                if (indexPositionValue == 1 && (aliveNeighbors < 2 || aliveNeighbors > 3))
                {
                    spawnGrid[y,x] = 3;
                    // Debug.Log("Cell X: " + x + " Y: " + y + " Value of spawnGrid: " + spawnGrid[y,x]);
                }
            }
        }
    
        for (int y = 0; y < array.GetLength(0); y++)
        {
            for (int x = 0; x < array.GetLength(1); x++)
            {
                if (spawnGrid[y,x] == 2 || spawnGrid[y,x] == 3)
                {
                    array[y, x] = spawnGrid[y,x];
                    spawnGrid[y,x] = 0;
                }
            }
        }
    }

    public void DeadAndSpawnerNewCells(int[,] array)
    {
        for (int y = 0; y < array.GetLength(0); y++)
        {
            for (int x = 0; x < array.GetLength(1); x++)
            {
                if (array[y,x] == 3)
                {
                    array[y,x] = 0;
                }
                if (array[y,x] == 2)
                {
                    array[y,x] = 1;
                }
            }
        }
    }

    public void CellColorDesignator(int[,] array)
    {
        for (int y = 0; y < array.GetLength(1); y++)
        {
            for (int x = 0; x < array.GetLength(1); x++)
            {
                GameObject g = new("X" + x + "Y" + y);
                g.transform.position = new Vector3(x - (horizontal - 0.5f), -y + (vertical - 0.5f));
                var s = g.AddComponent<SpriteRenderer>();
                s.sprite = sprite;

                if (array[y, x] == 0) // Dead
                {
                    s.color = new Color(1, 1, 1);
                    continue;
                }
                else if (array[y, x] == 1) // Alive
                {
                    s.enabled = true;
                    s.color = new Color(0, 0, 0);
                    continue;
                }
                else
                {
                    s.color = new Color(0.5f, 0.5f, 0.5f);
                    continue;
                }
            }
        }

    }
  
    public void CellGridMaker(int[,] array)
    {
        for (int y = 0; y < array.GetLength(1); y++)
        {
            for (int x = 0; x < array.GetLength(1); x++)
            {
                if (array[y, x] == 0) // Dead
                {
                    // s.color = new Color(1, 1, 1);
                    continue;
                }
                else if (array[y, x] == 1) // Alive
                {
                    // s.color = new Color(0, 0, 0);
                    continue;
                }
                // else if (array[y, x] == 2) // spawn Location
                // {
                //     s.color = new Color(0, 1, 0);
                //     continue;
                // }
                // else if (array[y, x] == 3) // Mark of death
                // {
                //     s.color = new Color(1, 0, 0);
                //     continue;
                // }
                else
                {
                    // s.color = new Color(0.5f, 0.5f, 0.5f);
                    continue;
                }
            }
        }
    }


}