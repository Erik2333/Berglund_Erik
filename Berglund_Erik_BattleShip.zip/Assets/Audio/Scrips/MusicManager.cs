using System;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MusicManager : MonoBehaviour
{
    AudioSource musicAudioSources;
    public AudioClip[] music;
    private float musicVolume;

    // This number is must be a large Number greater that buildIndex or music won't work.
    int currentMap = 99;
    
    public static MusicManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        musicAudioSources = GetComponent<AudioSource>();
        PlayMusic();
    }

    void PlayMusic()
    {
        if (currentMap == SceneManager.GetActiveScene().buildIndex)
        {
            return;
        }

        switch (SceneManager.GetActiveScene().buildIndex)
        {
            case 0:
                MenuMusic();
                return;

            case 1:
                Map1();
                return;
        }
    }

    void MenuMusic()
    {
        musicAudioSources.Stop();

        musicAudioSources.clip = music[0];

        musicAudioSources.volume = musicVolume;

        musicAudioSources.Play();
        
        currentMap = SceneManager.GetActiveScene().buildIndex;
    }

    void Map1()
    {
        musicAudioSources.Stop();

        musicAudioSources.clip = music[0];

        musicAudioSources.volume = musicVolume;

        musicAudioSources.Play();
        
        currentMap = SceneManager.GetActiveScene().buildIndex;
    }
}
