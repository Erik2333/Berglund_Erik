using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Torpedo : MonoBehaviour
{
    [SerializeField] List<Collider2D> listOfCollisions;
    [SerializeField] Vector2 Speed = new(0, 2);
    Rigidbody2D rb2D;

    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
        ShipManager.Instance.DisableButtons();
    }

    // Update is called once per frame
    void Update()
    {
        rb2D.velocity = Speed;
        Invoke("DestroyTorpedo", 2.5f);
    }
    
    private void OnCollisionEnter2D(Collision2D other) {
        
        var otherActorCollider2D = other.gameObject.GetComponent<Collider2D>();

        listOfCollisions.Add(otherActorCollider2D);
        otherActorCollider2D.enabled = false;

        if(other.gameObject.GetComponent<ShipID>().id != "0")
        {
            DestroyTorpedo();
            ShipManager.Instance.UpdateDisplayText("Explosions detected!<br>We hit something!");
        }

        ShipManager.Instance.UpdateAndClear();
    }
    
    void DestroyTorpedo()
    {
        var thisGameObject = this;
        thisGameObject.gameObject.SetActive(false);
    }

    void OnDisable()
    {
        foreach (var item in listOfCollisions)
        {
            item.enabled=true;
        }

        ShipManager.Instance.disableCells = false;
        ShipManager.Instance.DisableButtons(false);
    }
}
