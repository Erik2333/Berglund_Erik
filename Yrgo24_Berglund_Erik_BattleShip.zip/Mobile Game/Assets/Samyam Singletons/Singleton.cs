using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Singleton<T> : MonoBehaviour where T : Component
{
    // https://youtu.be/Ova7l0UB26U?t=296

    // Add this above the class to make sure its runs before other classes: [DefaultExecutionOrder(-1)]
    // To implement add class to Script. Example: public class ThisManager : Singleton<ThisManager>
    // Add a field: private ThisManager thisManager;
    // In start: thisManager = MyManager.Instance;

    private static T _instance;

    public static T Instance 
    {
        get
        {
            
            // var objs = FindObjectsOfType (typeof(T)) as T[];
            // if (objs.Length > 0)
            //     _instance = objs[0];
            // if (objs.Length > 1)
            //     Debug.LogError("There is more than one " + typeof(T).Name + " in the scene");
            if (_instance == null)
            {
                GameObject obj = new GameObject();
                obj.name = typeof(T).Name;
                _instance = obj.AddComponent<T>();

                // If you what to hide the gameobject in inspector ones its done then Uncomment code bellow.
                //obj.hideFlags = HideFlags.HideAndDontSave;
            }

            return _instance;
        }
    }

    private void OnDestroy()
    {
        if (_instance == this)
        {
            _instance = null;
        }
    }
}

public class SingletonPersistent<T> : MonoBehaviour where T : Component
{
    // https://www.youtube.com/watch?v=Ova7l0UB26U

    public static T Instance { get; private set; }

    // For this to work you will need to have this in the class that implements this.
    // public override void Awake() {
    // base.Awake();
    // }
    // If you are using Awake in that other script then simply add the rest of the code bellow base.Awake().

    public virtual void Awake()
    {
        if (Instance == null)
        {
            Instance = this as T;
            DontDestroyOnLoad(this);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}