using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameMap
{
    // https://www.youtube.com/watch?v=waEsGu--9P8

    int width;
    int height;
    float cellSize;
    int centerGridWidth;
    int centerGridHeight;

    int[,] gridArray;
    TextMesh [,] debugTextArray;

    public GameMap(int width,  int height, float cellSize, Vector2 position = default)
    {
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;

        gridArray = new int [width, height];
        debugTextArray = new TextMesh[width, height];

        centerGridWidth = (int)position.x;
        centerGridHeight = (int)position.y;

        for (int x = 0; x < gridArray.GetLength(0) ; x++)
        {
            for (int y = 0; y < gridArray.GetLength(1); y++)
            {
                debugTextArray[x,y] = CreateWorldText(gridArray[x, y].ToString(), null,
                GetWorldPosition(x, y) + new Vector3(cellSize, cellSize)*0.5f,
                5, null, TextAnchor.MiddleCenter);
                
                Debug.Log(x);
                Debug.Log(y);

                Debug.DrawLine(GetWorldPosition(x, y),
                GetWorldPosition(x, y + 1), Color.white, 10f);

                Debug.DrawLine(GetWorldPosition(x, y),
                GetWorldPosition(x + 1, y), Color.white, 10f);
            }
        }
        
        Debug.DrawLine(GetWorldPosition(0, height),
        GetWorldPosition(width, height), Color.white, 10f);

        Debug.DrawLine(GetWorldPosition(width, 0),
        GetWorldPosition(width, height), Color.white, 10f);

        SetValue(0, 0, 10);
    }

    private Vector3 GetWorldPosition(int x, int y)
    {
        return new Vector3(x, y) * cellSize;
    }

    void /*Vector2int*/ GetXY(Vector3 worldPosition, out int x, out int y)
    {
        x = Mathf.FloorToInt(worldPosition.x / cellSize) + centerGridWidth;
        
        y = Mathf.FloorToInt(worldPosition.y / cellSize) + centerGridWidth;

    }

    public void SetValue(int x, int y, int value)
    {
        if (x >= 0 && y >= 0 && x < width && y < height)
        {
            gridArray[x,y] = value;
            debugTextArray[x,y].text = gridArray[x,y].ToString();
        }
    }

    public void SetValue(Vector3 worldPosition, int value)
    {
        int x, y;
        GetXY(worldPosition, out x, out y);
        SetValue(x, y, value);
    }
    
    public static  TextMesh CreateWorldText(string text, Transform parent = null, Vector3 localPosition = default,
    int fontSize = 5,Color? color = null, TextAnchor textAnchor = TextAnchor.UpperLeft, TextAlignment textAlignment = TextAlignment.Left,
    int sortingOrder = default)
    {
        if (color == null)
        {
            color = Color.white;
        }

        return CreateWorldText(parent, text, localPosition, fontSize, (Color) color, textAnchor, textAlignment, sortingOrder);
    }

    static TextMesh CreateWorldText(Transform parent, string text, Vector3 localPosition, int fontSize, Color color,
    TextAnchor textAnchor, TextAlignment textAlignment, int sortingOrder)
    {
        GameObject gameObject = new GameObject("World_Text", typeof(TextMesh));
        Transform transform = gameObject.transform;
        transform.SetParent(parent, false);
        transform.localPosition = localPosition;
        TextMesh textMesh = gameObject.GetComponent<TextMesh>();
        textMesh.text = text;
        textMesh.fontSize = fontSize;
        textMesh.color = color;
        textMesh.anchor = textAnchor;
        textMesh.alignment = textAlignment;
        textMesh.GetComponent<MeshRenderer>().sortingOrder = sortingOrder;
        return textMesh;
    }
}