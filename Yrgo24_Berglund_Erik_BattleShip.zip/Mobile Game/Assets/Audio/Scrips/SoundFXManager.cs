using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.Mathematics;
using UnityEngine;

public class SoundFXManager : MonoBehaviour
{
    // https://www.youtube.com/watch?v=DU7cgVsU2rM

    [Tooltip("SpawnSoundFXClipAtPoint needs a Game Prefab with a AudioSource to work.")]
    [SerializeField] AudioSource spawnSoundClipPrefab;

    public static SoundFXManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    public void SpawnSoundFXClipAtPoint(AudioClip audioClip, Transform spawnTransform, float volume = 1, float pitch = 1)
    {
        if (spawnSoundClipPrefab == null)
        {
            Debug.LogWarning("spawnSoundClipPrefab is Null. Did you add the prefab?");
            return;
        }

        AudioSource audioSource = Instantiate(spawnSoundClipPrefab, spawnTransform.position, quaternion.identity); 

        audioSource.clip = audioClip;
        audioSource.volume = volume;
        audioSource.pitch = pitch;

        audioSource.Play();

        float clipLength = audioSource.clip.length;
        Destroy(audioSource.gameObject, clipLength);
    }
}
