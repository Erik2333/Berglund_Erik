using System;
using System.IO;
using UnityEngine;

[DefaultExecutionOrder(-1)]
public class SaveGameState : MonoBehaviour
{

    public static SaveGameState Instance { get; private set; }

    private void Start()
    {
        // UpdateShipID();
        // LoadShipIDFromJsonFile();

        // SaveAmmoData();
        // LoadAmmoFromJsonFile();

        // SaveTorpedoActive();
        // LoadTorpedoActiveFromJsonFile();
    }
    

    [Serializable]
    public class ShipIDData
    {
        public string[] idValue = new string[100] { //10x10

            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
            "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
        };
        public bool[] showShipValue = new bool[100] {

            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
        };
        public bool[] hitBySonarValue = new bool[100] {
            
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
            false, false, false, false, false, false, false, false, false, false,
        };
    }

    [Serializable]
    public class TorpedoData
    {
        public bool torpedoActiveValue;
        public Vector3 positionsValue;
    }

    [Serializable]
    public class TotalAmmoData
    {
        public int missileAmmoValue;
        public int torpedoAmmoValue;
        public int sonarAmmoValue;
    }
}


