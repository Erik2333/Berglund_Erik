using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class AudioScript : MonoBehaviour
{
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip[] audioClips;
    Dictionary<string, AudioClip> audioEffectsDictionary = new Dictionary<string, AudioClip>();

    private void Start() {
        audioSource = GetComponent<AudioSource>();
        InitializeAudioDictionary();
    }

    void InitializeAudioDictionary()
    {
        foreach (AudioClip clip in audioClips)
        {
            audioEffectsDictionary[clip.name] = clip;
        }
    }

    public void PlayAudioEffect(string effectName, float volume = 1, float pitch = 1)
    {
        // Example of sound clip name you need to use: Attack_1, Attack_2, Attack_3.
        // PlayAudioEffect("Attack"); Will at Random pick a sound that Contains "Attack" in its name.
        var audioEffects = audioEffectsDictionary.Where(kvp=> kvp.Key.ToLower()
        .Contains(effectName.ToLower())).Select(kvp => kvp.Value).ToList();

        if (audioEffects.Count > 0) {
            AudioClip randomClip = audioEffects[UnityEngine.Random.Range(0, audioEffects.Count)];

            audioSource.volume = volume;
            audioSource.pitch = pitch;
            audioSource.PlayOneShot(randomClip);
        }
        else { Debug.LogWarning("Audio Not Found"); }
    }
}
