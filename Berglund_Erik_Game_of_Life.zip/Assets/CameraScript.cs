using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    private Camera cam;

    [Range(20,500)]
    public float cameraZoom;

    [Range(1,10)]
    public float zoomModifier = 5;

    public float PanSpeed = 75f;

    private Vector3 dragOrigin;
    
    // Update is called once per frame
    void Start()
    {
        cameraZoom = cam.GetComponent<Camera>().orthographicSize;
    }
    
    void Update()
    {
        MouseWheelZoom();
        PanCamera();
        
    }

    void PanCamera()
    {
        float x = 0;
        float y = 0;
        Vector3 camMousePosition = cam.ScreenToWorldPoint(Input.mousePosition);

        if (Input.GetMouseButtonDown(1))
        {
            dragOrigin = camMousePosition;
        }

        if(Input.GetMouseButton(1))
        {
            Vector3 difference = dragOrigin - camMousePosition;
            cam.transform.position += difference;
        }

        if (Input.GetKey(KeyCode.W))
        {
            y = +1;
            Debug.Log("W need fixing");
        }
        if (Input.GetKey(KeyCode.S))
        {
            y = -1;
            Debug.Log("S need fixing");
        }
        if (Input.GetKey(KeyCode.A))
        {
            x = -1;
            Debug.Log("A need fixing");
        }
        if (Input.GetKey(KeyCode.D))
        {
            x = +1;
            Debug.Log("D need fixing");
        }
        Vector3 moveDirection = new Vector3(x,y).normalized;
        cam.transform.position += moveDirection * PanSpeed * Time.deltaTime;
    }

    void MouseWheelZoom()
    {
        if (Input.mouseScrollDelta.y < 0)
        {
            cameraZoom -= Input.mouseScrollDelta.y * zoomModifier;
        }
        else if (Input.mouseScrollDelta.y > 0)
        {
            cameraZoom -= Input.mouseScrollDelta.y * zoomModifier;
        }

        cam.GetComponent<Camera>().orthographicSize = cameraZoom;
    }
}