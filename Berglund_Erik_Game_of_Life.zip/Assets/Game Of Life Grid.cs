using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class GameOfLifeGrid : MonoBehaviour
{
    public GameObject cellPrefab;

    [SerializeField]
    private Camera cam;

    Cell[,] cells;

    float cellSize = 1f; //Don't touch

    int horizontal, vertical, columns, rows;

    [Range(0,100)]
    public int spawnChancePercentage = 15;

    int aliveNeighbors;

    [Range(1,60)]
    public int fps = 60;

    public bool pause = false; // KeyCode.P

    void Start()
    {
        QualitySettings.vSyncCount = 0;
        GenerateGrid();
    }

    void Update()
    {
        Application.targetFrameRate = fps;

        if (Input.GetKeyDown(KeyCode.P))
        pause = !pause;

        if (pause == false)
        CellDesignator();
        
        if (Input.GetKeyDown(KeyCode.K))
        {
            killGrid();
        }

        if (Input.GetKeyDown(KeyCode.G))
        {
            AddLivingCells();
        }
    }

    public void GenerateGrid()
    {
        vertical = (int)Camera.main.orthographicSize + 1;
        horizontal = (int)Camera.main.orthographicSize * (Screen.width / Screen.height) + 1;
        columns = horizontal * 2;
        rows = vertical * 2;
        cells = new Cell[columns, rows];

        for (int y = 0; y < rows; y++)
        {
            //for each column in each row
            for (int x = 0; x < columns; x++)
            {
                //Create our game cell objects, multiply by cellSize for correct world placement
                Vector2 newPos = new Vector2(x - (horizontal - 0.5f), -y + (vertical - 0.5f));
                var newCell = Instantiate(cellPrefab, newPos, Quaternion.identity);
                newCell.transform.localScale = Vector2.one * cellSize;
                cells[x, y] = newCell.GetComponent<Cell>();

                
                if (newPos[0] == cells.GetLength(0)*0.5f-cellSize*0.5f || newPos[0] == -(cells.GetLength(0)*0.5f-cellSize*0.5f) ||
                newPos[1] == cells.GetLength(1)*0.5f-cellSize*0.5f || newPos[1] == -(cells.GetLength(1)*0.5f-cellSize*0.5f))
                {
                    cells[x, y].deadSpace = true;
                    cells[x, y].GetComponent<SpriteRenderer>().color = new(1,0,0);
                    continue;
                }
                else if (Random.Range(0, 100) < spawnChancePercentage)
                {
                    cells[x, y].alive = true;
                    continue;
                }
            }
        }
        
        Debug.Log("Amount of active cells: " + (columns-2) * (rows-2));
    }

    public void CellDesignator()
    {
        // clear dead cells around living cells
        for (int y = 0; y < cells.GetLength(1); y++)
        {
            for (int x = 0; x < cells.GetLength(0); x++)
            {
                if (cells[x,y].alive == true)
                {
                    if (cells[x-1, y-1].coldCell == true)
                    {
                        cells[x-1, y-1].coldCell = false;
                    }

                    if (cells[x-1, y].coldCell == true)
                    {
                        cells[x-1, y].coldCell = false;
                    }
                    
                    if (cells[x-1, y+1].coldCell == true)
                    {
                        cells[x-1, y+1].coldCell = false;
                    }

                    if (cells[x, y-1].coldCell == true)
                    {
                        cells[x, y-1].coldCell = false;
                    }

                    if (cells[x, y+1].coldCell == true)
                    {
                        cells[x, y+1].coldCell = false;
                    }

                    if (cells[x+1, y-1].coldCell == true)
                    {
                        cells[x+1, y-1].coldCell = false;
                    }

                    if (cells[x+1, y].coldCell == true)
                    {
                        cells[x+1, y].coldCell = false;
                    }
                    
                    if (cells[x+1, y+1].coldCell == true)
                    {
                        cells[x+1, y+1].coldCell = false;
                    }
                }
            }
        }
        
        // Check cells around a dead and living cell.
        // Based on if the cell is alive or dead and how many aliveNeighbors they had give them either coldCell, dyingCell or newCell.
        for (int y = 0; y < cells.GetLength(1); y++)
        {
            for (int x = 0; x < cells.GetLength(0); x++)
            {
                aliveNeighbors = 0;


                if (cells[x,y].deadSpace == true)
                {
                    continue;
                }
                
                if (cells[x-1, y-1].alive == true)
                {
                    aliveNeighbors++;
                }

                if (cells[x-1, y].alive == true)
                {
                    aliveNeighbors++;
                }
                
                if (cells[x-1, y+1].alive == true)
                {
                    aliveNeighbors++;
                }

                if (cells[x, y-1].alive == true)
                {
                    aliveNeighbors++;
                }

                if (cells[x, y+1].alive == true)
                {
                    aliveNeighbors++;
                }

                if (cells[x+1, y-1].alive == true)
                {
                    aliveNeighbors++;
                }

                if (cells[x+1, y].alive == true)
                {
                    aliveNeighbors++;
                }
                
                if (cells[x+1, y+1].alive == true)
                {
                    aliveNeighbors++;
                }

                if (cells[x,y].alive == false && aliveNeighbors < 1)
                {
                    cells[x,y].coldCell = true;
                }

                if (cells[x,y].alive == false && aliveNeighbors == 3) // "alive" point for new cell
                {
                    cells[x,y].newCell = true;
                }

                if (cells[x,y].alive == true && (aliveNeighbors < 2 || aliveNeighbors > 3))
                {
                    cells[x,y].dyingCell = true;
                }

                if (cells[x, y].alive == false && aliveNeighbors < 1)
                {
                    cells[x,y].coldCell = true; // need a way to awaken
                }
            }
        }

        for (int y = 0; y < cells.GetLength(1); y++)
        {
            for (int x = 0; x < cells.GetLength(0); x++)
            {
                if (cells[x,y].dyingCell == true)
                {
                    cells[x,y].dyingCell = false;
                    cells[x,y].alive = false;
                    continue;
                }

                if (cells[x,y].newCell == true)
                {
                    cells[x,y].newCell = false;
                    cells[x,y].alive = true;
                    continue;
                }
            }
        }

        for (int y = 0; y < cells.GetLength(1); y++)
        {
            for (int x = 0; x < cells.GetLength(0); x++)
            {
                cells[x, y].UpdateCellStatus();
            }
        }
    }

    public void killGrid()
    {
        foreach (var item in cells)
        {
            if(item.deadSpace == false)
                item.alive = false;
        }
    }

    public void AddLivingCells()
    {
        foreach (var item in cells)
        {
            if (item.deadSpace == false)
            {
                if (Random.Range(0, 100) < spawnChancePercentage)
                {
                    Debug.Log("there are " + cells.GetLength(0) * cells.GetLength(1) + "in this array.");
                    item.alive = true;
                }
            }
        }
    }
}
