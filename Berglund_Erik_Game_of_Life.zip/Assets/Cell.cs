using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cell : MonoBehaviour
{
    public bool alive;
    public bool dyingCell;
    public bool newCell;
    public bool hiddenCell;
    public bool deadSpace; // deadSpace is there for a planed ignore screen edge cell function.
    public bool coldCell; // coldCell is planed for a function to skip this cell that aren't next to living cells.

    SpriteRenderer spriteRenderer;
    
    public void UpdateCellStatus()
    {
        spriteRenderer ??= GetComponent<SpriteRenderer>();

        if (deadSpace)
        {
            spriteRenderer.enabled = deadSpace;
        }
        else
        {
            spriteRenderer.enabled = alive;
        }

    }
}
