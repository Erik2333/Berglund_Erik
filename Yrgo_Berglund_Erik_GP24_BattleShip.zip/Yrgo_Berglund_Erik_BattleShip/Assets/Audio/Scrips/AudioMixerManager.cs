using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class AudioMixerManager : MonoBehaviour
{
    // https://www.youtube.com/watch?v=DU7cgVsU2rM

    bool stopMusic;
    bool stopFX;
    float savedMusicVolume;
    float savedSoundFXVolume;
    
    [SerializeField] AudioMixer audioMixer;

    public void MasterVolume(float volume)
    {
        audioMixer.SetFloat("MasterVolume", Mathf.Log10(volume) * 20f);
    }
    
    public void MusicVolume(float volume)
    {
        audioMixer.SetFloat("MusicVolume", Mathf.Log10(volume) * 20f);
        savedMusicVolume = Mathf.Log10(volume) * 20f;
    }

    public void SoundFXVolume(float volume)
    {
        audioMixer.SetFloat("SoundFXVolume", Mathf.Log10(volume) * 20f);
        savedSoundFXVolume = Mathf.Log10(volume) * 20f;
    }

    public void StopMusicVolume()
    {
        stopMusic = !stopMusic;

        if (stopMusic == true)
            audioMixer.SetFloat("MusicVolume", -80f);
        else
            audioMixer.SetFloat("MusicVolume", savedMusicVolume);
    }

    public void StopFXVolume()
    {
        stopFX = !stopFX;

        if (stopFX == true)
            audioMixer.SetFloat("SoundFXVolume", -80f);
        else
            audioMixer.SetFloat("SoundFXVolume", savedSoundFXVolume);
    }   
}
